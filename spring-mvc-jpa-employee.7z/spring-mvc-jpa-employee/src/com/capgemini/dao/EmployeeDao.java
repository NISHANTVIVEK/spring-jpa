package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Employee;

public interface EmployeeDao {
	public int createEmployee(Employee employee);
	public List<Employee> readAllEmployees();
	public int deleteEmployee(Employee employee);
	public void beginTransaction();
	public void commitTransaction();
}
