package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.model.Employee;
@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	@PersistenceContext
	private EntityManager entityManager;
	
	public int createEmployee(Employee employee){
		entityManager.persist(employee);
		return 1;
	}
	public List<Employee> readAllEmployees(){
		/*Query query = entityManager.createQuery("From Employee");
		List<Employee> empList = query.getResultList();*/
		TypedQuery<Employee> tquery = entityManager.createQuery("From Employee", Employee.class);
		List<Employee> empList = tquery.getResultList();
		return empList;
	}
	public int deleteEmployee(Employee employee){
		//Query query = entityManager.createQuery("DELETE From Employee e Where e.employeeId = "+employee.getEmployeeId());
		//Query query = entityManager.createQuery("DELETE From Employee e Where e.employeeId = :eid");
		Query query = entityManager.createNamedQuery("deleteById");
		query.setParameter("eid", employee.getEmployeeId());
		int result = query.executeUpdate();
		return result;
	}
	public void beginTransaction(){
		entityManager.getTransaction().begin();
	}
	public void commitTransaction(){
		entityManager.getTransaction().commit();
	}
}









