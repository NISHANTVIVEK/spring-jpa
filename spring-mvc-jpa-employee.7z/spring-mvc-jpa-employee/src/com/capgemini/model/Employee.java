package com.capgemini.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="EMP")
@NamedQuery(name="deleteById", query="DELETE From Employee e Where e.employeeId = :eid")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Emp_Id_Generator")
	@SequenceGenerator(sequenceName="Emp_Seq", name="Emp_Id_Generator", allocationSize=1)
	@Column(name="Emp_Id")
	private int employeeId;
	
	@Column(name="Emp_Name")
	private String employeeName;

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}
	@Column(name="Emp_Sal")
	private double employeeSalary;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
}
