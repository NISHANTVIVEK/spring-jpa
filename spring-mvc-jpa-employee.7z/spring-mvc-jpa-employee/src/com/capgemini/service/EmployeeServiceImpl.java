package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.model.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao = null;
	
	@Transactional
	public boolean addEmployee(Employee employee){
		//getDao().beginTransaction();
		int result = getDao().createEmployee(employee);
		//getDao().commitTransaction();
		
		if(result ==1){
			return true;
		}
		return false;
	}
	public List<Employee> viewAllEmployees(){
		return getDao().readAllEmployees();
	}
	
	@Transactional
	public boolean deleteEmployee(Employee employee){
		//getDao().beginTransaction();
		int result = getDao().deleteEmployee(employee);
		//getDao().commitTransaction();
		
		if(result == 1){
			return true;
		}
		return false;
	}
	public EmployeeDao getDao() {
		return dao;
	}
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}
}

