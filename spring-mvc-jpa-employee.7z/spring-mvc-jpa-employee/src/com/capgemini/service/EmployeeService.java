package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Employee;

public interface EmployeeService {
	public boolean addEmployee(Employee employee);
	public List<Employee> viewAllEmployees();
	public boolean deleteEmployee(Employee employee);
}
