package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.model.Employee;
import com.capgemini.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String homePage(){
		return "index";
	}
	@RequestMapping(path="/addEmployeePage", method=RequestMethod.GET)
	public String addEmployeePage(){
		return "addEmployee";
	}
	@RequestMapping(path="/addEmployee.do", method=RequestMethod.POST)
	public String processAddEmployee(@RequestParam("employeeName") String name, 
			@RequestParam("employeeSalary") double salary){
		Employee employee = new Employee();
		employee.setEmployeeName(name);
		employee.setEmployeeSalary(salary);
		boolean result = service.addEmployee(employee);
		if(result)
			return "redirect:viewEmployees.do";
		else
			return "error";
	}

	@RequestMapping(path="/viewEmployees.do")
	public String viewAllEmployees(Model model){
		List<Employee> list = service.viewAllEmployees();
		model.addAttribute("employeeList", list);
		return "viewEmployee";
	}
}




